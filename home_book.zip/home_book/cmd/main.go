package main

import (
	"conn/models"

	"github.com/gin-gonic/gin"
	_ "github.com/lib/pq"
	_"gopkg.in/yaml.v3"
)
type Config struct {
	Server   ServerConfig   `yaml:"server"`
	Database DatabaseConfig `yaml:"database"`
	Filter   FilterConfig   `yaml:"filter"`
}

type ServerConfig struct {
	Host string `yaml:"localhost"`
	Port string `yaml:"5432"`
}

type DatabaseConfig struct {
	Host     string `yaml:"localhost"`
	Username string `yaml:"postgres"`
	Password string `yaml:"Dilshod@2005"`
	Port     string `yaml:"5432"`
	Name     string `yaml:"postgres"`
}

type FilterConfig struct {
	Artist string `yaml:"artist"`
	Title  string `yaml:"title"`
	Price  int    `yaml:"price"`
}

func main() {
	
	router := gin.Default()
	router.GET("/albums", models.GetAllAlbum)
	router.GET("/albums/:id", models.GetById)
	router.POST("/albums/", models.CreateAlbum)
	router.PUT("/albums/:id", models.UpdateAlbum)
	router.DELETE("/albums/:id", models.DeleteAlbum)
	router.GET("/artist/:title", models.ArtistTitle)
	router.GET("/artist/price/:price", models.ArtistPrice)
	router.GET("/title/:artist", models.TitleArtist)
	router.GET("/title/price/:price", models.TitlePrice)
	router.Run(":8080")
}
